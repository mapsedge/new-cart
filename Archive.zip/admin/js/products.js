/* global SimpleNotification, jQuery */
(function () {
	'use strict';

	const AJAX     = NC.adminUrl + '?route=products/ajax';
	const CAT_AJAX = NC.adminUrl + '?route=categories/ajax';

	const tbody    = document.getElementById('prod-tbody');
	const emptyRow = document.getElementById('prod-empty-row');
	const drawer   = document.getElementById('prod-drawer');
	const overlay  = document.getElementById('drawer-overlay');
	const chkAll   = document.getElementById('chk-all');
	const btnBulk  = document.getElementById('btn-bulk-delete');

	let allCategories = [];

	// ── Ajax ──────────────────────────────────────────────────────────────────
	async function ajax(url, data) {
		const fd = new FormData();
		Object.entries(data).forEach(([k, v]) => fd.append(k, v));
		const r = await fetch(url, { method: 'POST', body: fd });
		return r.json();
	}

	function post(data)    { return ajax(AJAX,     data); }
	function postCat(data) { return ajax(CAT_AJAX, data); }

	function notifyOk(msg)  { SimpleNotification.success({ text: msg }); }
	function notifyErr(msg) { SimpleNotification.error({ text: msg }); }

	function debounce(fn, ms) {
		var t;
		return function () {
			var a = arguments;
			clearTimeout(t);
			t = setTimeout(function () { fn.apply(null, a); }, ms);
		};
	}

	// ── ios-toggle read helper ─────────────────────────────────────────────────
	// With the new component, label has the id, hidden input has _nc_{id}
	function togVal(id) {
		var hidden = document.getElementById('_nc_' + id);
		if (hidden) return parseInt(hidden.value || 0) ? 1 : 0;
		var tog = document.querySelector('ios-toggle[name="' + id + '"]');
		if (tog) {
			var cb = tog.querySelector('input[type=checkbox]');
			return cb && cb.checked ? 1 : 0;
		}
		return 0;
	}

	function setTogVal(id, v) {
		var label  = document.getElementById(id);
		if (!label) return;
		var toggle = label.closest('ios-toggle');
		if (!toggle) return;
		var cb     = toggle.querySelector('input[type=checkbox]');
		var hidden = toggle.querySelector('input[type=hidden]');
		var on     = !!parseInt(v);
		if (cb)     cb.checked   = on;
		if (hidden) hidden.value = on ? 1 : 0;
	}

	// ── Load ──────────────────────────────────────────────────────────────────
	async function loadProducts() {
		const res = await post({ action: 'list' });
		if (!res.ok) { notifyErr(res.message); return; }
		renderRows(res.rows);
	}

	async function loadCategories() {
		const res = await post({ action: 'categories' });
		if (res.ok) allCategories = res.categories || [];
	}

	function renderRows(rows) {
		Array.from(tbody.querySelectorAll('tr[data-id]')).forEach(r => r.remove());
		if (!rows || !rows.length) { emptyRow.style.display = ''; return; }
		emptyRow.style.display = 'none';
		rows.forEach(r => tbody.appendChild(buildRow(r)));
		initDragDrop();
		updateBulkBtn();
	}

	function stockClass(stock) {
		if (stock <= 0) return 'stock-zero';
		if (stock <= 5) return 'stock-low';
		return 'stock-ok';
	}

	function fmtPrice(v) {
		return '$' + parseFloat(v || 0).toFixed(2);
	}

	function buildRow(d) {
		const tr      = document.createElement('tr');
		tr.dataset.id = d.id;
		const inactive = d.status == 0;

		const price     = parseFloat(d.price || 0).toFixed(2);
		const listPrice = parseFloat(d.list_price || 0);
		// List price only shown if > price
		const listHtml = listPrice > parseFloat(price)
			? '<span class="list-price" title="List price">' + fmtPrice(listPrice) + '</span>'
			: '';

		const stock = parseInt(d.stock || 0);

		tr.innerHTML =
			'<td class="col-drag"><span class="drag-handle">&#8942;</span></td>' +
			'<td>' +
				'<button class="prod-name-link" data-id="' + d.id + '">' + esc(d.name) + '</button>' +
				(d.sku ? '<div class="prod-sku">' + esc(d.sku) + '</div>' : '') +
			'</td>' +
			'<td><div class="prod-cats">' + esc(d.categories || '—') + '</div></td>' +
			'<td class="col-price">' +
				'<div class="price-col">' +
					'<span class="price-cell price-display" data-id="' + d.id + '" title="Click to edit">' +
						fmtPrice(price) +
					'</span>' +
					listHtml +
				'</div>' +
				'<div class="price-edit-wrap" id="price-edit-' + d.id + '">' +
					'<input type="number" min="0" step="0.01" class="price-input" data-field="price" data-id="' + d.id + '" value="' + price + '" placeholder="Price">' +
					'<input type="number" min="0" step="0.01" class="price-input" data-field="list_price" data-id="' + d.id + '" value="' + listPrice.toFixed(2) + '" placeholder="List">' +
				'</div>' +
			'</td>' +
			'<td class="col-stock">' +
				'<span class="stock-display ' + stockClass(stock) + '" data-id="' + d.id + '" title="Click to edit">' + stock + '</span>' +
				'<span class="stock-edit-wrap" id="stock-edit-' + d.id + '">' +
					'<input type="number" min="0" step="1" class="stock-input" data-id="' + d.id + '" value="' + stock + '">' +
				'</span>' +
			'</td>' +
			'<td class="col-active">' +
				'<ios-toggle ' + (d.status == 1 ? 'checked' : '') + ' size="sm" data-id="' + d.id + '" data-field="status"></ios-toggle>' +
			'</td>' +
			'<td class="col-toggle">' +
				'<ios-toggle ' + (d.featured == 1 ? 'checked' : '') + ' size="sm" data-id="' + d.id + '" data-field="featured"></ios-toggle>' +
			'</td>' +
			'<td class="col-delete">' +
				'<span class="delete-fade' + (inactive ? ' show' : '') + '" id="prod-del-' + d.id + '">' +
				'<delete-in-place caption="&#128465;" confirm="Delete?" data-id="' + d.id + '"></delete-in-place>' +
				'</span>' +
			'</td>' +
			'<td class="col-check">' +
				'<input type="checkbox" class="row-chk" data-id="' + d.id + '"' + (inactive ? '' : ' disabled') + '>' +
			'</td>';

		return tr;
	}

	function updateRow(d) {
		const tr    = tbody.querySelector('tr[data-id="' + d.id + '"]');
		const newTr = buildRow(d);
		if (!tr) {
			emptyRow.style.display = 'none';
			tbody.appendChild(newTr);
			initDragDrop();
		} else {
			tbody.replaceChild(newTr, tr);
		}
		updateBulkBtn();
	}

	// ── Click-to-edit price ────────────────────────────────────────────────────
	tbody.addEventListener('click', function (e) {
		// Price
		const priceSpan = e.target.closest('.price-display');
		if (priceSpan) {
			const id       = priceSpan.dataset.id;
			const wrap     = document.getElementById('price-edit-' + id);
			const priceCol = priceSpan.closest('.price-col');
			if (wrap && priceCol) {
				priceCol.style.display = 'none';
				wrap.classList.add('active');
				wrap.querySelector('input').focus();
			}
		}
		// Stock
		const stockSpan = e.target.closest('.stock-display');
		if (stockSpan) {
			const id   = stockSpan.dataset.id;
			const wrap = document.getElementById('stock-edit-' + id);
			if (wrap) {
				stockSpan.style.display = 'none';
				wrap.classList.add('active');
				wrap.querySelector('input').focus();
			}
		}
	});

	tbody.addEventListener('blur', async function (e) {
		// Price blur
		const priceInput = e.target.closest('.price-input');
		if (priceInput) {
			const id   = priceInput.dataset.id;
			const wrap = document.getElementById('price-edit-' + id);
			if (!wrap) return;
			const inputs  = wrap.querySelectorAll('input');
			const price   = parseFloat(inputs[0]?.value || 0);
			const listPr  = parseFloat(inputs[1]?.value || 0);
			const res = await post({ action: 'save_prices', id, price, list_price: listPr });
			wrap.classList.remove('active');
			const tr = tbody.querySelector('tr[data-id="' + id + '"]');
			if (tr) {
				const priceCol = tr.querySelector('.price-col');
				if (priceCol) priceCol.style.display = '';
				const pd = tr.querySelector('.price-display');
				if (pd) pd.textContent = '$' + price.toFixed(2);
				const ld = tr.querySelector('.list-price');
				if (ld) ld.textContent = listPr > price ? '$' + listPr.toFixed(2) : '';
			}
			if (!res.ok) notifyErr(res.message);
		}
		// Stock blur
		const stockInput = e.target.closest('.stock-input');
		if (stockInput) {
			const id    = stockInput.dataset.id;
			const wrap  = document.getElementById('stock-edit-' + id);
			const stock = parseInt(stockInput.value || 0);
			const res = await post({ action: 'save_stock', id, stock });
			if (wrap) wrap.classList.remove('active');
			const tr = tbody.querySelector('tr[data-id="' + id + '"]');
			if (tr) {
				const sd = tr.querySelector('.stock-display');
				if (sd) {
					sd.textContent = stock;
					sd.className = 'stock-display ' + stockClass(stock);
					sd.style.display = '';
				}
			}
			if (!res.ok) notifyErr(res.message);
		}
	}, true); // capture phase for blur

	// ── Drawer tabs ───────────────────────────────────────────────────────────
	document.querySelectorAll('.drawer-tab').forEach(function (btn) {
		btn.addEventListener('click', function () {
			document.querySelectorAll('.drawer-tab').forEach(t => t.classList.remove('active'));
			document.querySelectorAll('.drawer-tab-panel').forEach(p => p.classList.remove('active'));
			this.classList.add('active');
			document.getElementById('panel-' + this.dataset.panel).classList.add('active');
		});
	});

	// ── Category checkboxes ───────────────────────────────────────────────────
	function renderCatList(selectedIds) {
		const list = document.getElementById('prod-cat-list');
		list.innerHTML = '';
		if (!allCategories.length) {
			list.innerHTML = '<span style="color:var(--nc-text-dim);font-size:.83rem">No categories. Add one below.</span>';
			return;
		}
		allCategories.forEach(function (c) {
			const label = document.createElement('label');
			const cb    = document.createElement('input');
			cb.type  = 'checkbox';
			cb.value = c.id;
			cb.name  = 'prod_cat';
			if (selectedIds.map(String).includes(String(c.id))) cb.checked = true;
			label.appendChild(cb);
			label.appendChild(document.createTextNode(' ' + c.name));
			list.appendChild(label);
		});
	}

	function getSelectedCatIds() {
		return Array.from(document.querySelectorAll('#prod-cat-list input[type=checkbox]:checked'))
			.map(cb => cb.value);
	}

	// ── Quick-add category ────────────────────────────────────────────────────
	document.getElementById('btn-quick-add-cat').addEventListener('click', async function () {
		const input = document.getElementById('quick-cat-name');
		const name  = input.value.trim();
		if (!name) { notifyErr('Enter a category name.'); return; }

		this.disabled = true;
		const res = await post({ action: 'quick_add_category', name });
		this.disabled = false;

		if (!res.ok) { notifyErr(res.message); return; }

		// Add to allCategories and re-render with new one checked
		allCategories.push(res.category);
		const selected = getSelectedCatIds();
		selected.push(String(res.category.id));
		renderCatList(selected);
		input.value = '';
		notifyOk('Category "' + res.category.name + '" added. Remember to complete its details in the Categories section.');
	});

	// ── Drawer ────────────────────────────────────────────────────────────────
	function openDrawer(title) {
		document.getElementById('drawer-title').textContent = title;
		drawer.classList.add('open');
		overlay.classList.add('show');
		setTimeout(function () {
			if (!window._trumbProdDone && window.jQuery && jQuery.fn.trumbowyg) {
				jQuery('#prod-desc-long').trumbowyg({
					svgPath: '/js/vendor/trumbowyg/src/ui/icons.svg',
					btns: [
						['bold', 'italic', 'underline'],
						['link'],
						['unorderedList', 'orderedList'],
						['indent', 'outdent'],
						['viewHTML']
					]
				});
				window._trumbProdDone = true;
			}
		}, 50);
	}

	function closeDrawer() {
		drawer.classList.remove('open');
		overlay.classList.remove('show');
	}

	function resetDrawer() {
		document.getElementById('prod-id').value         = '';
		document.getElementById('prod-name').value       = '';
		document.getElementById('prod-sku').value        = '';
		document.getElementById('prod-price').value      = '';
		document.getElementById('prod-list-price').value = '';
		document.getElementById('prod-stock').value      = '0';
		document.getElementById('prod-desc').value       = '';
		document.getElementById('quick-cat-name').value  = '';
		if (window._trumbProdDone) jQuery('#prod-desc-long').trumbowyg('html', '');
		else document.getElementById('prod-desc-long').value = '';
		setTogVal('prod-active',   1);
		setTogVal('prod-featured', 0);
		setTogVal('prod-free-ship',0);
		renderCatList([]);
	}

	// ── Add ───────────────────────────────────────────────────────────────────
	async function addProduct() {
		resetDrawer();
		openDrawer('Add Product');
		document.getElementById('prod-name').focus();
	}

	document.getElementById('btn-add-product').addEventListener('click', addProduct);
	document.getElementById('btn-add-first').addEventListener('click', addProduct);

	// ── Edit ──────────────────────────────────────────────────────────────────
	tbody.addEventListener('click', async function (e) {
		const btn = e.target.closest('.prod-name-link');
		if (!btn) return;
		const res = await post({ action: 'get', id: btn.dataset.id });
		if (!res.ok) { notifyErr(res.message); return; }
		const d = res.row;

		document.getElementById('prod-id').value         = d.id;
		document.getElementById('prod-name').value       = d.name;
		document.getElementById('prod-sku').value        = (d.sku || '').toUpperCase();
		document.getElementById('prod-price').value      = parseFloat(d.price || 0).toFixed(2);
		document.getElementById('prod-list-price').value = parseFloat(d.list_price || 0).toFixed(2);
		document.getElementById('prod-stock').value      = d.stock;
		document.getElementById('prod-desc').value       = d.description || '';

		if (window._trumbProdDone) jQuery('#prod-desc-long').trumbowyg('html', d.description_long || '');
		else document.getElementById('prod-desc-long').value = d.description_long || '';

		setTogVal('prod-active',    d.status      == 1 ? 1 : 0);
		setTogVal('prod-featured',  d.featured    == 1 ? 1 : 0);
		setTogVal('prod-free-ship', d.free_shipping == 1 ? 1 : 0);

		renderCatList(d.category_ids || []);
		openDrawer('Edit Product');
	});

	// ── SKU uppercase ─────────────────────────────────────────────────────────
	document.getElementById('prod-sku').addEventListener('input', function () {
		var pos = this.selectionStart;
		this.value = this.value.toUpperCase();
		this.setSelectionRange(pos, pos);
	});

	// ── Save ──────────────────────────────────────────────────────────────────
	document.getElementById('btn-drawer-save').addEventListener('click', async function () {
		const nameEl = document.getElementById('prod-name');
		if (!nameEl.reportValidity()) return;

		const descLong = window._trumbProdDone
			? jQuery('#prod-desc-long').trumbowyg('html')
			: document.getElementById('prod-desc-long').value;

		this.disabled = true;
		const res = await post({
			action:           'save',
			id:               document.getElementById('prod-id').value,
			name:             document.getElementById('prod-name').value.trim(),
			sku:              document.getElementById('prod-sku').value.toUpperCase(),
			price:            document.getElementById('prod-price').value,
			list_price:       document.getElementById('prod-list-price').value || 0,
			stock:            document.getElementById('prod-stock').value,
			status:           togVal('prod-active'),
			featured:         togVal('prod-featured'),
			free_shipping:    togVal('prod-free-ship'),
			description:      document.getElementById('prod-desc').value,
			description_long: descLong,
			category_ids:     JSON.stringify(getSelectedCatIds()),
		});
		this.disabled = false;

		if (!res.ok) { notifyErr(res.message); return; }
		notifyOk(res.message);
		updateRow(res.row);
		closeDrawer();
	});

	document.getElementById('drawer-close').addEventListener('click', closeDrawer);
	document.getElementById('btn-drawer-cancel').addEventListener('click', closeDrawer);
	overlay.addEventListener('click', closeDrawer);

	// ── Debounced inline toggles ──────────────────────────────────────────────
	var debouncedToggle = debounce(function (id, field, value) {
		post({ action: 'toggle', id: id, field: field, value: value });
	}, 1000);

	document.addEventListener('ios-toggle', function (e) {
		const src = e.detail.source;
		if (!src.dataset.id || !src.dataset.field) return;

		// Show/hide delete and enable/disable checkbox when status changes
		if (src.dataset.field === 'status') {
			const id       = src.dataset.id;
			const inactive = !e.detail.checked;
			const delSpan  = document.getElementById('prod-del-' + id);
			const chk      = tbody.querySelector('tr[data-id="' + id + '"] .row-chk');
			if (delSpan) delSpan.classList.toggle('show', inactive);
			if (chk)     chk.disabled = !inactive;
		}

		debouncedToggle(src.dataset.id, src.dataset.field, e.detail.value);
	});

	// ── Delete single ─────────────────────────────────────────────────────────
	tbody.addEventListener('dip-confirm', async function (e) {
		const id  = e.detail.id;
		const res = await post({ action: 'delete', id });
		if (!res.ok) { notifyErr(res.message); return; }
		const tr = tbody.querySelector('tr[data-id="' + id + '"]');
		if (tr) {
			tr.classList.add('row-removing');
			setTimeout(function () {
				tr.remove();
				if (!tbody.querySelector('tr[data-id]')) emptyRow.style.display = '';
				updateBulkBtn();
			}, 300);
		}
		notifyOk(res.message);
	});

	// ── Bulk delete ───────────────────────────────────────────────────────────
	chkAll.addEventListener('change', function () {
		tbody.querySelectorAll('.row-chk:not(:disabled)').forEach(c => c.checked = this.checked);
		updateBulkBtn();
	});
	tbody.addEventListener('change', function (e) {
		if (e.target.classList.contains('row-chk')) updateBulkBtn();
	});

	function updateBulkBtn() {
		const n = tbody.querySelectorAll('.row-chk:checked').length;
		btnBulk.disabled    = n === 0;
		btnBulk.textContent = n > 0 ? 'Delete Selected (' + n + ')' : 'Delete Selected';
	}

	btnBulk.addEventListener('click', async function () {
		const ids = Array.from(tbody.querySelectorAll('.row-chk:checked')).map(c => c.dataset.id);
		if (!ids.length) return;
		this.disabled = true;
		const res = await post({ action: 'bulk_delete', ids: JSON.stringify(ids) });
		this.disabled = false;
		if (!res.ok) { notifyErr(res.message); return; }
		ids.forEach(function (id) {
			const tr = tbody.querySelector('tr[data-id="' + id + '"]');
			if (tr) { tr.classList.add('row-removing'); setTimeout(() => tr.remove(), 300); }
		});
		setTimeout(function () {
			if (!tbody.querySelector('tr[data-id]')) emptyRow.style.display = '';
			updateBulkBtn();
		}, 350);
		chkAll.checked = false;
		notifyOk(res.message);
	});

	// ── Drag-drop reorder — delegated ─────────────────────────────────────────
	var dragSrc = null;

	tbody.addEventListener('mousedown', function (e) {
		var handle = e.target.closest('.drag-handle');
		if (!handle) return;
		var tr = handle.closest('tr[data-id]');
		if (tr) tr.setAttribute('draggable', 'true');
	});
	tbody.addEventListener('mouseup', function () {
		tbody.querySelectorAll('tr[data-id]').forEach(function (tr) { tr.setAttribute('draggable', 'false'); });
	});
	tbody.addEventListener('dragstart', function (e) {
		var tr = e.target.closest('tr[data-id]');
		if (!tr) return;
		dragSrc = tr; tr.classList.add('dragging');
		e.dataTransfer.effectAllowed = 'move';
	});
	tbody.addEventListener('dragend', function () {
		if (dragSrc) dragSrc.classList.remove('dragging');
		tbody.querySelectorAll('tr').forEach(function (r) { r.classList.remove('drag-over'); });
		tbody.querySelectorAll('tr[data-id]').forEach(function (tr) { tr.setAttribute('draggable', 'false'); });
		dragSrc = null; saveOrder();
	});
	tbody.addEventListener('dragover', function (e) {
		e.preventDefault();
		var tr = e.target.closest('tr[data-id]');
		tbody.querySelectorAll('tr').forEach(function (r) { r.classList.remove('drag-over'); });
		if (tr && tr !== dragSrc) tr.classList.add('drag-over');
	});
	tbody.addEventListener('drop', function (e) {
		e.preventDefault();
		var tr = e.target.closest('tr[data-id]');
		if (!tr || tr === dragSrc || !dragSrc) return;
		var rows = Array.from(tbody.querySelectorAll('tr[data-id]'));
		var from = rows.indexOf(dragSrc), to = rows.indexOf(tr);
		if (from < to) tbody.insertBefore(dragSrc, tr.nextSibling);
		else           tbody.insertBefore(dragSrc, tr);
	});

	function initDragDrop() { /* delegated — no per-row setup needed */ }

	async function saveOrder() {
		var ids = Array.from(tbody.querySelectorAll('tr[data-id]')).map(r => r.dataset.id);
		await post({ action: 'reorder', ids: JSON.stringify(ids) });
	}

	function esc(str) {
		return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
	}

	Promise.all([loadProducts(), loadCategories()]);

})();
