<?php
/* Smarty version 4.5.4, created on 2026-04-06 02:08:55
  from '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/categories/list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d315b75c04b3_91736438',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '922b8a9ce06d77de0750b1afef8c61539795ed4d' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/categories/list.html',
      1 => 1775441180,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69d315b75c04b3_91736438 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_142305470269d315b7566ef7_69943270', "title");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_31994638169d315b7569ee2_67081373', "head");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_105990055669d315b756a7d9_16857128', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_45449918169d315b756bd13_30369995', "scripts");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../layout.html");
}
/* {block "title"} */
class Block_142305470269d315b7566ef7_69943270 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_142305470269d315b7566ef7_69943270',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Categories — <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);
}
}
/* {/block "title"} */
/* {block "head"} */
class Block_31994638169d315b7569ee2_67081373 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_31994638169d315b7569ee2_67081373',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" href="/admin/css/categories.css">
<?php
}
}
/* {/block "head"} */
/* {block "content"} */
class Block_105990055669d315b756a7d9_16857128 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_105990055669d315b756a7d9_16857128',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="nc-toolbar">
	<button class="btn btn-primary" id="btn-add-category">+ Add Category</button>
	<button class="btn btn-danger" id="btn-bulk-delete" disabled>Delete Selected</button>
</div>

<table class="nc-table" id="cat-table">
	<thead>
		<tr>
			<th class="col-drag"></th>
			<th>Category Name</th>
			<th>Parent</th>
			<th class="col-status">Status</th>
			<th class="col-toggle">Featured</th>
			<th class="col-browse"></th>
			<th class="col-delete"></th>
			<th class="col-check"><input type="checkbox" id="chk-all" title="Select all"></th>
		</tr>
	</thead>
	<tbody id="cat-tbody">
		<tr id="cat-empty-row">
			<td colspan="8">
				<div class="nc-empty">
					<p>No categories yet.</p>
					<button class="btn btn-primary" id="btn-add-first">Add your first category</button>
				</div>
			</td>
		</tr>
	</tbody>
</table>

<div id="drawer-overlay"></div>

<me-drawer id="cat-drawer">
	<drawer-head>
		<h2 id="drawer-title">Add Category</h2>
		<button class="drawer-close" id="drawer-close">&times;</button>
	</drawer-head>
	<drawer-content>
		<input type="hidden" id="cat-id" value="">

		<div class="df">
			<label for="cat-name">Category Name <span class="field-required">*</span></label>
			<input type="text" id="cat-name" maxlength="255" required>
		</div>

		<div class="df">
			<label for="cat-parent">Parent Category</label>
			<select id="cat-parent">
				<option value="0">&mdash; Top Level &mdash;</option>
			</select>
		</div>

		<div class="df">
			<label for="cat-seo">Page Title (SEO)</label>
			<input type="text" id="cat-seo" maxlength="300" placeholder="Defaults to category name if left blank">
		</div>

		<div class="df">
			<label for="cat-html-long">Description</label>
			<textarea id="cat-html-long" rows="6"></textarea>
		</div>

		<div class="df-row">
			<div class="df">
				<label>Status</label>
				<roller-select id="cat-status" name="cat-status" value="1">
					<rs-item value="0">Not Active</rs-item>
					<rs-item value="1">Active</rs-item>
					<rs-item value="2">Browse Only</rs-item>
				</roller-select>
			</div>
			<div class="df-toggle">
				<ios-toggle id="cat-featured" name="cat-featured" size="sm"></ios-toggle>
				<label for="cat-featured">Featured</label>
			</div>
		</div>

	</drawer-content>
	<drawer-foot>
		<button class="btn btn-secondary" id="btn-drawer-cancel">Cancel</button>
		<button class="btn btn-primary" id="btn-drawer-save">Save Category</button>
	</drawer-foot>
</me-drawer>

<?php
}
}
/* {/block "content"} */
/* {block "scripts"} */
class Block_45449918169d315b756bd13_30369995 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'scripts' => 
  array (
    0 => 'Block_45449918169d315b756bd13_30369995',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
>
var NC = {
	adminUrl:       '<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
',
	rootUrl:        '<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
',
	siteName:       '<?php echo strtr((string)$_smarty_tpl->tpl_vars['site_name']->value, array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", 
                       "\n" => "\\n", "</" => "<\/", "<!--" => "<\!--", "<s" => "<\s", "<S" => "<\S",
                       "`" => "\\`", "\${" => "\\\$\{"));?>
',
	incompleteCats: <?php echo json_encode($_smarty_tpl->tpl_vars['incomplete_cat_ids']->value);?>

};
<?php echo '</script'; ?>
>
<link rel="stylesheet" href="/js/vendor/SimpleNotification/simpleNotification.min.css">
<?php echo '<script'; ?>
 src="/js/vendor/SimpleNotification/simpleNotification.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/roller-select.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/ios-toggle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/delete-in-place.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/admin/js/categories.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block "scripts"} */
}
