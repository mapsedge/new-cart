<?php
/* Smarty version 4.5.4, created on 2026-04-06 02:04:50
  from '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/plugins/list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d314c2b69fb4_32655215',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c36b09b922a7c6c0e096edacf87479d26c8af41d' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/plugins/list.html',
      1 => 1775420166,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69d314c2b69fb4_32655215 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_86463099269d314c2b65442_05273044', "title");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_120434501969d314c2b67b28_84056056', "head");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16727232069d314c2b68425_77077534', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_171432284969d314c2b69309_88499853', "scripts");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../layout.html");
}
/* {block "title"} */
class Block_86463099269d314c2b65442_05273044 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_86463099269d314c2b65442_05273044',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Plugins — <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);
}
}
/* {/block "title"} */
/* {block "head"} */
class Block_120434501969d314c2b67b28_84056056 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_120434501969d314c2b67b28_84056056',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" href="/admin/css/plugins.css">
<?php
}
}
/* {/block "head"} */
/* {block "content"} */
class Block_16727232069d314c2b68425_77077534 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_16727232069d314c2b68425_77077534',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="plugin-notice" id="plugin-notice">
	<span class="notice-icon">&#9888;</span>
	<div>
		<strong>Back up before installing.</strong>
		Always back up your database and files before installing or removing a plugin.
		If something goes wrong, a backup is the only way to fully recover.
		<!-- <a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=setup#backup">Go to backup</a> -->
	</div>
	<button class="notice-dismiss" id="notice-dismiss" title="Dismiss">&times;</button>
</div>

<div class="plugin-upload" id="plugin-upload-zone">
	<div class="upload-icon">&#128229;</div>
	<p>Drop a plugin .zip here, or click to browse</p>
	<p class="upload-hint">Plugins are .zip files containing a plugin.xml manifest</p>
</div>

<input type="file" id="plugin-file-input" accept=".zip" style="display:none">

<div class="upload-progress" id="upload-progress">
	<span class="spinner"></span>
	<span id="upload-progress-msg">Installing…</span>
</div>

<table class="nc-table">
	<thead>
		<tr>
			<th>Plugin</th>
			<th>Author</th>
			<th>Link</th>
			<th class="col-toggle">Enabled</th>
			<th class="col-delete"></th>
		</tr>
	</thead>
	<tbody id="plugin-tbody">
		<tr>
			<td colspan="5"><div class="nc-empty">No plugins installed.</div></td>
		</tr>
	</tbody>
</table>

<?php
}
}
/* {/block "content"} */
/* {block "scripts"} */
class Block_171432284969d314c2b69309_88499853 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'scripts' => 
  array (
    0 => 'Block_171432284969d314c2b69309_88499853',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
>
var NC = {
	adminUrl: '<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
',
	rootUrl:  '<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
'
};
<?php echo '</script'; ?>
>
<link rel="stylesheet" href="/js/vendor/SimpleNotification/simpleNotification.min.css">
<?php echo '<script'; ?>
 src="/js/vendor/SimpleNotification/simpleNotification.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/ios-toggle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/delete-in-place.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/admin/js/plugins.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block "scripts"} */
}
