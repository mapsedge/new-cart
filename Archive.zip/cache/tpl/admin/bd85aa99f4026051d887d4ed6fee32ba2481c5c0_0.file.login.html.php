<?php
/* Smarty version 4.5.4, created on 2026-04-05 01:59:20
  from '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/login.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d1c1f818fb03_90381600',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bd85aa99f4026051d887d4ed6fee32ba2481c5c0' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/login.html',
      1 => 1775349382,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69d1c1f818fb03_90381600 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/media/william/8TB-DRIVE/www/sites/new-cart/lib/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Login — <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
</title>
	<style>
		*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

		body {
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
			background: #f0f2f5;
			min-height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 2rem;
		}

		#login-box {
			background: #fff;
			border: 1px solid #c9cdd4;
			box-shadow: 0 4px 32px rgba(0,0,0,.18);
			border-radius: .75rem;
			width: 100%;
			max-width: 380px;
			overflow: hidden;
		}

		#login-header {
			background: #2c3e50;
			color: #fff;
			padding: 1.5rem 2rem;
			text-align: center;
		}

		#login-header h1 {
			font-size: 1.1rem;
			font-weight: 600;
			opacity: .75;
			margin-bottom: .2rem;
			text-transform: uppercase;
			letter-spacing: .08em;
		}

		#login-header .store-name {
			font-size: 1.4rem;
			font-weight: 700;
		}

		#login-form { padding: 2rem; }

		.field { margin-bottom: 1rem; }
		.field label {
			display: block;
			font-size: .85rem;
			font-weight: 600;
			color: #1a1a1a;
			margin-bottom: .3rem;
		}
		.field input {
			width: 100%;
			padding: .55rem .75rem;
			border: 1px solid #d1d5db;
			border-radius: .375rem;
			font-size: .95rem;
			color: #1a1a1a;
			outline: none;
			transition: border-color .15s, box-shadow .15s;
		}
		.field input:focus {
			border-color: #2563eb;
			box-shadow: 0 0 0 3px rgba(37,99,235,.12);
		}

		.error-msg {
			background: #fee2e2;
			color: #7f1d1d;
			border-radius: .375rem;
			padding: .6rem .85rem;
			font-size: .87rem;
			font-weight: 500;
			margin-bottom: 1rem;
		}

		button[type=submit] {
			width: 100%;
			padding: .6rem;
			background: #2563eb;
			color: #fff;
			border: none;
			border-radius: .375rem;
			font-size: .95rem;
			font-weight: 600;
			cursor: pointer;
			transition: filter .15s;
			margin-top: .5rem;
		}
		button[type=submit]:hover { filter: brightness(.9); }

		#login-footer {
			text-align: center;
			padding: .85rem;
			font-size: .75rem;
			color: #555;
			border-top: 1px solid #e5e7eb;
		}
	</style>
</head>
<body>

<div id="login-box">
	<div id="login-header">
		<h1>Admin</h1>
		<div class="store-name"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
</div>
	</div>
	<div id="login-form">
		<?php if ($_smarty_tpl->tpl_vars['error']->value) {?>
		<div class="error-msg"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['error']->value, ENT_QUOTES, 'UTF-8', true);?>
</div>
		<?php }?>
		<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=login">
			<div class="field">
				<label for="username">Username</label>
				<input type="text" id="username" name="username" autocomplete="username" autofocus>
			</div>
			<div class="field">
				<label for="password">Password</label>
				<input type="password" id="password" name="password" autocomplete="current-password">
			</div>
			<button type="submit">Log In</button>
		</form>
	</div>
	<div id="login-footer">
		new-cart &mdash; &copy; <?php echo smarty_modifier_date_format(time(),'%Y');?>
 Map's Edge Creative
	</div>
</div>

</body>
</html>
<?php }
}
