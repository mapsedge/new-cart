<?php
/* Smarty version 4.5.4, created on 2026-04-06 02:08:55
  from '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/layout.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d315b76d7128_32163173',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd73ced735c038abb7f0755357869b8d17422492d' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/admin/tpl/layout.html',
      1 => 1775440880,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69d315b76d7128_32163173 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/media/william/8TB-DRIVE/www/sites/new-cart/lib/vendor/smarty/smarty/libs/plugins/modifier.truncate.php','function'=>'smarty_modifier_truncate',),1=>array('file'=>'/media/william/8TB-DRIVE/www/sites/new-cart/lib/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_81101762369d315b75c72d1_44110692', "title");
?>
</title>
	<link rel="stylesheet" href="/admin/css/vars.css">
	<style>
		*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

		html, body { height: 100%; }

		body {
			font-family: var(--nc-font);
			background: var(--nc-bg-page);
			color: var(--nc-text);
			font-size: .92rem;
		}

		/* ── Top bar ── */
		#topbar {
			position: fixed;
			top: 0; left: 0; right: 0;
			height: var(--nc-topbar-h);
			background: var(--nc-topbar-bg);
			color: var(--nc-topbar-text);
			display: flex;
			align-items: center;
			padding: 0 1rem;
			z-index: 200;
			gap: .75rem;
		}

		#sidebar-toggle {
			background: none;
			border: none;
			color: var(--nc-topbar-text);
			cursor: pointer;
			padding: .35rem .4rem;
			border-radius: .3rem;
			display: flex;
			flex-direction: column;
			gap: 4px;
			flex-shrink: 0;
			transition: background .15s;
		}
		#sidebar-toggle:hover { background: rgba(255,255,255,.1); }
		#sidebar-toggle span {
			display: block;
			width: 20px; height: 2px;
			background: var(--nc-topbar-text);
			border-radius: 2px;
			transition: transform .25s, opacity .25s;
		}

		#store-logo-area {
			flex: 1;
			font-size: 1.05rem;
			font-weight: 700;
			color: var(--nc-topbar-text);
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		#store-logo-area img {
			max-height: 36px;
			width: auto;
			vertical-align: middle;
		}

		#topbar-right {
			display: flex;
			align-items: center;
			gap: 1.25rem;
			flex-shrink: 0;
		}

		#topbar-right a {
			color: var(--nc-topbar-text);
			text-decoration: none;
			font-size: .85rem;
			opacity: .85;
			display: flex;
			align-items: center;
			gap: .3rem;
			transition: opacity .15s;
		}
		#topbar-right a:hover { opacity: 1; }

		.topbar-divider {
			width: 1px;
			height: 20px;
			background: rgba(255,255,255,.2);
		}

		#admin-user-label {
			font-size: .82rem;
			opacity: .7;
		}

		#admin-avatar {
			width: 28px; height: 28px;
			border-radius: 50%;
			object-fit: cover;
			border: 2px solid rgba(255,255,255,.3);
			vertical-align: middle;
		}

		#admin-avatar-initials {
			width: 28px; height: 28px;
			border-radius: 50%;
			background: var(--nc-primary, #2563eb);
			color: #fff;
			font-size: .72rem;
			font-weight: 700;
			display: inline-flex;
			align-items: center;
			justify-content: center;
			border: 2px solid rgba(255,255,255,.3);
			vertical-align: middle;
		}

		/* ── Sidebar ── */
		#sidebar {
			position: fixed;
			top: var(--nc-topbar-h);
			left: 0;
			bottom: 0;
			width: var(--nc-sidebar-w);
			background: var(--nc-sidebar-bg);
			overflow-y: auto;
			overflow-x: hidden;
			z-index: 100;
			transition: width .25s ease;
			display: flex;
			flex-direction: column;
		}

		#sidebar.collapsed { width: var(--nc-sidebar-w-collapsed); }

		#sidebar nav { flex: 1; padding: .5rem 0; }

		#sidebar nav a {
			display: flex;
			align-items: center;
			gap: .75rem;
			padding: .65rem 1rem;
			color: var(--nc-sidebar-text);
			text-decoration: none;
			font-size: .88rem;
			font-weight: 500;
			white-space: nowrap;
			overflow: hidden;
			transition: background .15s, color .15s;
			border-left: 3px solid transparent;
		}

		#sidebar nav a:hover {
			background: var(--nc-sidebar-hover);
			color: #fff;
		}

		#sidebar nav a.active {
			background: var(--nc-sidebar-hover);
			border-left-color: var(--nc-sidebar-active);
			color: #fff;
		}

		#sidebar nav a .nav-icon {
			flex-shrink: 0;
			width: 18px;
			text-align: center;
			font-size: 1rem;
			opacity: .8;
		}

		#sidebar nav a .nav-label {
			transition: opacity .2s;
		}

		#sidebar.collapsed nav a .nav-label { opacity: 0; pointer-events: none; }

		#sidebar nav .nav-section {
			font-size: .68rem;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .08em;
			color: var(--nc-sidebar-dim);
			padding: 1rem 1rem .3rem;
			white-space: nowrap;
			overflow: hidden;
			transition: opacity .2s;
		}

		#sidebar.collapsed nav .nav-section { opacity: 0; }

		/* ── Sidebar footer ── */
		#sidebar-foot {
			padding: .85rem 1rem;
			font-size: .72rem;
			color: var(--nc-sidebar-dim);
			border-top: 1px solid rgba(255,255,255,.07);
			white-space: nowrap;
			overflow: hidden;
			transition: opacity .2s;
			line-height: 1.6;
		}
		#sidebar.collapsed #sidebar-foot { opacity: 0; }

		/* ── Main content ── */
		#main {
			margin-left: var(--nc-sidebar-w);
			margin-top: var(--nc-topbar-h);
			min-height: calc(100vh - var(--nc-topbar-h));
			transition: margin-left .25s ease;
			display: flex;
			flex-direction: column;
		}

		#main.sidebar-collapsed { margin-left: var(--nc-sidebar-w-collapsed); }

		#content-header {
			background: var(--nc-bg);
			border-bottom: 1px solid var(--nc-border);
			padding: 1rem 1.5rem;
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 1rem;
		}

		#content-header h1 {
			font-size: 1.15rem;
			font-weight: 700;
			color: var(--nc-text);
		}

		#content {
			padding: 1.5rem;
			flex: 1;
		}

		/* ── Admin footer ── */
		#admin-footer {
			text-align: center;
			padding: .85rem;
			font-size: .75rem;
			color: var(--nc-text-secondary);
			border-top: 1px solid var(--nc-border);
			background: var(--nc-bg);
		}

		/* ── Flash messages ── */
		.flash {
			padding: .7rem 1rem;
			border-radius: .375rem;
			margin-bottom: 1rem;
			font-weight: 500;
			font-size: .88rem;
		}
		.flash-success { background: #dcfce7; color: #14532d; }
		.flash-error   { background: #fee2e2; color: #7f1d1d; }
		.flash-info    { background: #dbeafe; color: #1e3a5f; }

		/* ── Reminder banners ── */
		#reminders-wrap { margin-bottom: 1rem; }
		.reminder-banner {
			display: flex; align-items: flex-start; gap: .65rem;
			background: #fff8e1; border: 1px solid #f59e0b;
			border-left: 4px solid #f59e0b;
			border-radius: .375rem;
			padding: .65rem .9rem; margin-bottom: .5rem;
			font-size: .87rem; color: #1a1a1a; line-height: 1.5;
		}
		.reminder-icon { flex-shrink: 0; color: #b45309; }

		/* ── Alternating table rows — global ── */
		.nc-table tbody tr:nth-child(even) td { background: #f5f6f8; }
		.nc-table tbody tr.dragging td,
		.nc-table tbody tr.drag-over td { background: transparent; }

		/* ── Tooltip on collapsed sidebar ── */
		#sidebar.collapsed nav a { position: relative; }
		#sidebar.collapsed nav a::after {
			content: attr(data-label);
			position: absolute;
			left: calc(var(--nc-sidebar-w-collapsed) + 8px);
			top: 50%;
			transform: translateY(-50%);
			background: #1a1a1a;
			color: #fff;
			padding: .3rem .6rem;
			border-radius: .3rem;
			font-size: .8rem;
			white-space: nowrap;
			pointer-events: none;
			opacity: 0;
			transition: opacity .15s;
			z-index: 300;
		}
		#sidebar.collapsed nav a:hover::after { opacity: 1; }
	</style>
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_74821689269d315b75cc0f0_37500643', "head");
?>

</head>
<body>

<div id="topbar">
	<button id="sidebar-toggle" title="Toggle menu" aria-label="Toggle menu">
		<span></span><span></span><span></span>
	</button>
	<div id="store-logo-area">
				<span id="topbar-store-name"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
</span>
	</div>
	<div id="topbar-right">
		<?php if ($_smarty_tpl->tpl_vars['admin_avatar']->value) {?>
		<img src="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['admin_avatar']->value, ENT_QUOTES, 'UTF-8', true);?>
" id="admin-avatar" alt="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['admin_user']->value, ENT_QUOTES, 'UTF-8', true);?>
">
		<?php } else { ?>
		<span id="admin-avatar-initials"><?php echo mb_strtoupper((string) smarty_modifier_truncate($_smarty_tpl->tpl_vars['admin_user']->value,2,'',true) ?? '', 'UTF-8');?>
</span>
		<?php }?>
		<span id="admin-user-label"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['admin_user']->value, ENT_QUOTES, 'UTF-8', true);?>
</span>
		<div class="topbar-divider"></div>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
" target="_blank" rel="noopener">
			Visit Store
			<svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<path d="M7 1h4v4M11 1L5 7"/><path d="M9 7v4H1V3h4"/>
			</svg>
		</a>
		<div class="topbar-divider"></div>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=logout">Log Out</a>
	</div>
</div>

<div id="sidebar">
	<nav>
		<?php $_smarty_tpl->_assignInScope('p', (($tmp = $_smarty_tpl->tpl_vars['page']->value ?? null)===null||$tmp==='' ? 'dashboard' ?? null : $tmp));?>

		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=dashboard" data-label="Dashboard" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'dashboard') {?>active<?php }?>">
			<span class="nav-icon">&#9783;</span><span class="nav-label">Dashboard</span>
		</a>

		<?php if (($_smarty_tpl->tpl_vars['access']->value&8)) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=orders" data-label="Orders" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'orders') {?>active<?php }?>">
			<span class="nav-icon">&#128722;</span><span class="nav-label">Orders</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=customers" data-label="Customers" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'customers') {?>active<?php }?>">
			<span class="nav-icon">&#128101;</span><span class="nav-label">Customers</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=categories" data-label="Categories" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'categories') {?>active<?php }?>">
			<span class="nav-icon">&#128193;</span><span class="nav-label">Categories</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=products" data-label="Products" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'products') {?>active<?php }?>">
			<span class="nav-icon">&#128085;</span><span class="nav-label">Products</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=options" data-label="Options" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'options') {?>active<?php }?>">
			<span class="nav-icon">&#9881;</span><span class="nav-label">Options</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=discounts" data-label="Discounts" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'discounts') {?>active<?php }?>">
			<span class="nav-icon">&#127991;</span><span class="nav-label">Discounts</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=locations" data-label="Locations & Tax" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'locations') {?>active<?php }?>">
			<span class="nav-icon">&#127758;</span><span class="nav-label">Locations &amp; Tax</span>
		</a>
		<?php }?>

		<?php if (($_smarty_tpl->tpl_vars['access']->value&32)) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=reports" data-label="Reports" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'reports') {?>active<?php }?>">
			<span class="nav-icon">&#128202;</span><span class="nav-label">Reports</span>
		</a>
		<?php }?>

		<?php if (($_smarty_tpl->tpl_vars['access']->value&64)) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=reviews" data-label="Reviews" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'reviews') {?>active<?php }?>">
			<span class="nav-icon">&#11088;</span><span class="nav-label">Reviews</span>
		</a>
		<?php }?>

		<?php if (($_smarty_tpl->tpl_vars['access']->value&8)) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=shipping" data-label="Shipping" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'shipping') {?>active<?php }?>">
			<span class="nav-icon">&#128666;</span><span class="nav-label">Shipping</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=themes" data-label="Themes" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'themes') {?>active<?php }?>">
			<span class="nav-icon">&#127912;</span><span class="nav-label">Themes</span>
		</a>
		<?php }?>

		<?php if (($_smarty_tpl->tpl_vars['access']->value&128)) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=pages" data-label="Pages" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'pages') {?>active<?php }?>">
			<span class="nav-icon">&#128196;</span><span class="nav-label">Pages</span>
		</a>
		<?php }?>

		<?php if ($_smarty_tpl->tpl_vars['access']->value == 254) {?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=plugins" data-label="Plugins" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'plugins') {?>active<?php }?>">
			<span class="nav-icon">&#129695;</span><span class="nav-label">Plugins</span>
		</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_admin']->value;?>
?route=setup" data-label="Setup & Utilities" class="<?php if ($_smarty_tpl->tpl_vars['p']->value == 'setup') {?>active<?php }?>">
			<span class="nav-icon">&#128295;</span><span class="nav-label">Setup &amp; Utilities</span>
		</a>
		<?php }?>

	</nav>
	<div id="sidebar-foot">
		new-cart<br>
		&copy; <?php echo smarty_modifier_date_format(time(),'%Y');?>
 Map's Edge Creative
	</div>
</div>

<div id="main">

	<div id="content-header">
		<h1><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_72582711569d315b75dd413_85957745', "page_title");
?>
</h1>
		<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_195420206269d315b75de4e2_94704682', "content_actions");
?>

	</div>

	<div id="content">
		<?php if ($_smarty_tpl->tpl_vars['flash']->value) {?>
		<div class="flash flash-<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['flash']->value['type'], ENT_QUOTES, 'UTF-8', true);?>
"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['flash']->value['message'], ENT_QUOTES, 'UTF-8', true);?>
</div>
		<?php }?>

				<?php if ($_smarty_tpl->tpl_vars['reminders']->value) {?>
		<div id="reminders-wrap">
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['reminders']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
			<div class="reminder-banner" data-entity="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['r']->value['entity'], ENT_QUOTES, 'UTF-8', true);?>
" data-entity-id="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['r']->value['entity_id'], ENT_QUOTES, 'UTF-8', true);?>
">
				<span class="reminder-icon">&#9888;</span>
				<span class="reminder-text">
					<strong><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['r']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</strong> &mdash; <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['r']->value['message'], ENT_QUOTES, 'UTF-8', true);?>

				</span>
			</div>
			<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</div>
		<?php }?>

		<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_135073312169d315b76d2c65_27525011', "content");
?>

	</div>

	<div id="admin-footer">
		new-cart &mdash; &copy; <?php echo smarty_modifier_date_format(time(),'%Y');?>
 <a href="https://mapsedgecreative.com" target="_blank" rel="noopener" style="color:inherit">Map's Edge Creative</a>
	</div>

</div>
<?php echo '<script'; ?>
>
(function () {
	'use strict';

	const sidebar = document.getElementById('sidebar');
	const main    = document.getElementById('main');
	const toggle  = document.getElementById('sidebar-toggle');

	const COLLAPSED_KEY = 'nc_sidebar_collapsed';

	function setCollapsed(on) {
		sidebar.classList.toggle('collapsed', on);
		main.classList.toggle('sidebar-collapsed', on);
		localStorage.setItem(COLLAPSED_KEY, on ? '1' : '0');
	}

	// Restore state
	if (localStorage.getItem(COLLAPSED_KEY) === '1') {
		setCollapsed(true);
	}

	toggle.addEventListener('click', function () {
		setCollapsed(!sidebar.classList.contains('collapsed'));
	});
})();
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.7.1.min.js"><?php echo '</script'; ?>
>
<link rel="stylesheet" href="/js/vendor/trumbowyg/trumbowyg.css">
<?php echo '<script'; ?>
 src="/js/vendor/trumbowyg/trumbowyg.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
if (window.jQuery) {
	jQuery.trumbowyg.svgPath = '/js/vendor/trumbowyg/src/ui/icons.svg';
}
<?php echo '</script'; ?>
>
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_138473317969d315b76d58c2_90752136', "scripts");
?>


</body>
</html>
<?php }
/* {block "title"} */
class Block_81101762369d315b75c72d1_44110692 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_81101762369d315b75c72d1_44110692',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
echo (($tmp = $_smarty_tpl->tpl_vars['page_title']->value ?? null)===null||$tmp==='' ? 'Admin' ?? null : $tmp);?>
 — <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);
}
}
/* {/block "title"} */
/* {block "head"} */
class Block_74821689269d315b75cc0f0_37500643 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_74821689269d315b75cc0f0_37500643',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "head"} */
/* {block "page_title"} */
class Block_72582711569d315b75dd413_85957745 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_72582711569d315b75dd413_85957745',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
echo htmlspecialchars((string)(($tmp = $_smarty_tpl->tpl_vars['page_title']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);
}
}
/* {/block "page_title"} */
/* {block "content_actions"} */
class Block_195420206269d315b75de4e2_94704682 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content_actions' => 
  array (
    0 => 'Block_195420206269d315b75de4e2_94704682',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content_actions"} */
/* {block "content"} */
class Block_135073312169d315b76d2c65_27525011 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_135073312169d315b76d2c65_27525011',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php if ($_smarty_tpl->tpl_vars['page']->value == 'dashboard') {?>
			<p>Welcome back, <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['admin_user']->value, ENT_QUOTES, 'UTF-8', true);?>
.</p>
		<?php } elseif ($_smarty_tpl->tpl_vars['page']->value == '404') {?>
			<p>Page not found.</p>
		<?php }?>
		<?php
}
}
/* {/block "content"} */
/* {block "scripts"} */
class Block_138473317969d315b76d58c2_90752136 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'scripts' => 
  array (
    0 => 'Block_138473317969d315b76d58c2_90752136',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "scripts"} */
}
