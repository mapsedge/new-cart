<?php
/* Smarty version 4.5.4, created on 2026-04-05 01:59:21
  from '/media/william/8TB-DRIVE/www/sites/new-cart/tpl/home.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d1c1f9323067_05540736',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '145a97d88ea7094350db2b6570163a15b003d6af' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/tpl/home.html',
      1 => 1775289694,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69d1c1f9323067_05540736 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_127799450969d1c1f931fe13_59840417', "title");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_211102869569d1c1f9321ad1_47806214', "content");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "layout.html");
}
/* {block "title"} */
class Block_127799450969d1c1f931fe13_59840417 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_127799450969d1c1f931fe13_59840417',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Welcome — <?php echo $_smarty_tpl->tpl_vars['site_name']->value;
}
}
/* {/block "title"} */
/* {block "content"} */
class Block_211102869569d1c1f9321ad1_47806214 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_211102869569d1c1f9321ad1_47806214',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h2>Welcome to <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
</h2>
<?php
}
}
/* {/block "content"} */
}
