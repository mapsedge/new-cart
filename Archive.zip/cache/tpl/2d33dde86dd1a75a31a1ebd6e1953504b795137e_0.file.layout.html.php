<?php
/* Smarty version 4.5.4, created on 2026-04-05 01:59:21
  from '/media/william/8TB-DRIVE/www/sites/new-cart/tpl/layout.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.4',
  'unifunc' => 'content_69d1c1f9342a85_26712820',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2d33dde86dd1a75a31a1ebd6e1953504b795137e' => 
    array (
      0 => '/media/william/8TB-DRIVE/www/sites/new-cart/tpl/layout.html',
      1 => 1775289686,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:partials/sidebar_categories.html' => 1,
    'file:partials/sidebar_new.html' => 1,
    'file:partials/sidebar_top.html' => 1,
    'file:../../usermods/sidebar.html' => 1,
  ),
),false)) {
function content_69d1c1f9342a85_26712820 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/media/william/8TB-DRIVE/www/sites/new-cart/lib/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_142137156969d1c1f932acb6_52111639', "title");
?>
</title>
	<link rel="stylesheet" href="/css/main.css">
	<link rel="stylesheet" href="/usermods/css/store.css">
	<link rel="stylesheet" href="/js/vendor/SimpleNotification/simpleNotification.min.css">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_49104712869d1c1f932ba08_40210224', "head");
?>

</head>
<body>

<header id="masthead">
	<div id="store-logo">
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['site_name']->value;?>
</a>
	</div>
	<div id="store-search">
		<form action="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
" method="get">
			<input type="hidden" name="route" value="search">
			<input type="text" name="q" placeholder="Search..." value="<?php echo (($tmp = $_smarty_tpl->tpl_vars['q']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
			<button type="submit">Go</button>
		</form>
	</div>
	<div id="store-cart-summary">
		<a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=cart">
			Cart: <?php echo (($tmp = $_smarty_tpl->tpl_vars['cart_qty']->value ?? null)===null||$tmp==='' ? 0 ?? null : $tmp);?>
 item(s) — <?php echo $_smarty_tpl->tpl_vars['site_currency']->value;
echo (($tmp = $_smarty_tpl->tpl_vars['cart_total']->value ?? null)===null||$tmp==='' ? '0.00' ?? null : $tmp);?>

		</a>
	</div>
</header>

<nav id="top-nav">
	<ul>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
">Home</a></li>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=contact">Contact</a></li>
		<?php if ($_smarty_tpl->tpl_vars['is_logged_in']->value) {?>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=account">Account</a></li>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=account/logout">Log Out</a></li>
		<?php } else { ?>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=account/login">Log In</a></li>
		<?php }?>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=checkout">Checkout</a></li>
		<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_root']->value;?>
?route=cart">Cart</a></li>
	</ul>
</nav>

<?php if ($_smarty_tpl->tpl_vars['flash']->value) {?>
<div id="flash" class="flash flash-<?php echo $_smarty_tpl->tpl_vars['flash']->value['type'];?>
"><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['flash']->value['message'], ENT_QUOTES, 'UTF-8', true);?>
</div>
<?php }?>

<div id="main-wrap">

	<aside id="sidebar">
				<div class="sidebar-box">
			<div class="sidebar-box-head">Categories</div>
			<div class="sidebar-box-body">
				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_195304245869d1c1f9334394_44189059', "sidebar_categories");
?>

			</div>
		</div>
				<div class="sidebar-box">
			<div class="sidebar-box-head">What's New</div>
			<div class="sidebar-box-body">
				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_97113856069d1c1f933c060_78467634', "sidebar_new");
?>

			</div>
		</div>
				<div class="sidebar-box">
			<div class="sidebar-box-head">Top Sellers</div>
			<div class="sidebar-box-body">
				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13355690069d1c1f933d343_55950490', "sidebar_top");
?>

			</div>
		</div>
				<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9833534169d1c1f933e348_21836495', "sidebar_extra");
?>

	</aside>

	<main id="content">
		<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_50161706669d1c1f933f378_23640022', "content");
?>

	</main>

</div>
<footer id="footer">
	<p>&copy; <?php echo smarty_modifier_date_format(time(),'%Y');?>
 <?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
. All rights reserved.</p>
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_196601092769d1c1f9341638_64420390', "footer_extra");
?>

</footer>

<?php echo '<script'; ?>
 src="/js/vendor/SimpleNotification/simpleNotification.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/ios-toggle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/delete-in-place.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/vendor/maps-edge-date.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/app.js"><?php echo '</script'; ?>
>
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_138036621269d1c1f9341f97_08320878', "scripts");
?>


</body>
</html>
<?php }
/* {block "title"} */
class Block_142137156969d1c1f932acb6_52111639 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_142137156969d1c1f932acb6_52111639',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['site_name']->value;
}
}
/* {/block "title"} */
/* {block "head"} */
class Block_49104712869d1c1f932ba08_40210224 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_49104712869d1c1f932ba08_40210224',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "head"} */
/* {block "sidebar_categories"} */
class Block_195304245869d1c1f9334394_44189059 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidebar_categories' => 
  array (
    0 => 'Block_195304245869d1c1f9334394_44189059',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<?php $_smarty_tpl->_subTemplateRender("file:partials/sidebar_categories.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
				<?php
}
}
/* {/block "sidebar_categories"} */
/* {block "sidebar_new"} */
class Block_97113856069d1c1f933c060_78467634 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidebar_new' => 
  array (
    0 => 'Block_97113856069d1c1f933c060_78467634',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<?php $_smarty_tpl->_subTemplateRender("file:partials/sidebar_new.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
				<?php
}
}
/* {/block "sidebar_new"} */
/* {block "sidebar_top"} */
class Block_13355690069d1c1f933d343_55950490 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidebar_top' => 
  array (
    0 => 'Block_13355690069d1c1f933d343_55950490',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<?php $_smarty_tpl->_subTemplateRender("file:partials/sidebar_top.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
				<?php
}
}
/* {/block "sidebar_top"} */
/* {block "sidebar_extra"} */
class Block_9833534169d1c1f933e348_21836495 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'sidebar_extra' => 
  array (
    0 => 'Block_9833534169d1c1f933e348_21836495',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php $_smarty_tpl->_subTemplateRender("file:../../usermods/sidebar.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('_optional'=>true), 0, false);
?>
		<?php
}
}
/* {/block "sidebar_extra"} */
/* {block "content"} */
class Block_50161706669d1c1f933f378_23640022 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_50161706669d1c1f933f378_23640022',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block "footer_extra"} */
class Block_196601092769d1c1f9341638_64420390 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer_extra' => 
  array (
    0 => 'Block_196601092769d1c1f9341638_64420390',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "footer_extra"} */
/* {block "scripts"} */
class Block_138036621269d1c1f9341f97_08320878 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'scripts' => 
  array (
    0 => 'Block_138036621269d1c1f9341f97_08320878',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "scripts"} */
}
